the result are:
MLE base line error rate:
known: 0.07516597276921344, unknown is: 0.75043630017452, total is: 0.15229741851888767

viterbi error rate:
known words error rate: :  0.16023404973556876 unknown words error rate :  0.75043630017452  total error rate :  0.2276487590949865

vibteri with add one smoothing error rate:
known_words: 0.14616856081917406, unknown_words: 0.7146596858638743,total error:  0.21110335891557863

viterbi with pw error rate:
known words error rate: :  0.16252545824847253 unknown words error rate :  0.44131455399061037  total error rate :  0.1684441343566232

vivterbi with pw and add one smoothing error rate:
known words error rate: :  0.14287169042769854 unknown words error rate :  0.5586854460093897  total error rate :  0.15169939200637894


the confusion matrix as excel file was added as well